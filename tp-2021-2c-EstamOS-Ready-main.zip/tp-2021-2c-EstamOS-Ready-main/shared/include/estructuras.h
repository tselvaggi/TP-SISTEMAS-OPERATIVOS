#ifndef SHARED_INCLUDE_ESTRUCTURAS_H_
#define SHARED_INCLUDE_ESTRUCTURAS_H_

#include "librerias.h"
#include <semaphore.h>
















#endif /* SHARED_INCLUDE_ESTRUCTURAS_H_ */
