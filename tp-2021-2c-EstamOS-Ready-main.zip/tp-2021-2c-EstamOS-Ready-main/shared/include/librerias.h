#ifndef SHARED_INCLUDE_LIBRERIAS_H_
#define SHARED_INCLUDE_LIBRERIAS_H_

#include<stdio.h>
#include<stdlib.h>
#include<commons/log.h>
#include<commons/string.h>
#include<commons/config.h>
#include<commons/collections/list.h>
#include<readline/readline.h>
#include<sys/socket.h>
#include<sys/time.h>
#include<netdb.h>
#include "loggers_config.h"
#include<commons/temporal.h>
#include<commons/txt.h>



#endif /* SHARED_INCLUDE_LIBRERIAS_H_ */
